#include <stdio.h>
#include "NUC100Series.h"
#include "Start_Up.h"
#include "core_cm0.h"
#include "Scankey.h"
#include "Seven_Segment.h"
#include "LCD.h"
#include "gpio.h"

void Start_Up(void){
	SYS_UnlockReg(); // Unlock protected registers
	
	CLK->PWRCON |= (1ul << 0); // Enable ex 12Mhz clk
  while(!(CLK->CLKSTATUS & CLK_CLKSTATUS_XTL12M_STB_Msk));
	
	CLK->PWRCON |= (1ul << 3); // Enable in 10kHz clk
  while(!(CLK->CLKSTATUS & CLK_CLKSTATUS_IRC10K_STB_Msk));
	
	CLK->PWRCON |= (1ul << 2); // Enable in 22.1184 MHz clk
	while(!(CLK->CLKSTATUS & CLK_CLKSTATUS_IRC22M_STB_Msk)); 
	
	// PLL configuration starts
	CLK->PLLCON &= ~(1ul<<19); //0: PLL input is HXT 12MHz (default). 1: PLL input is HIRC 22MHz
	CLK->PLLCON &= ~(1ul<<16); //0: PLL in normal mode. 1: PLL in power-down mode (default)
	CLK->PLLCON &= (~(0x01FFul << 0));
	CLK->PLLCON |= 255; //frequency: 257Mhz
	CLK->PLLCON &= ~(1ul<<18); //0: enable PLL clock out. 1: disable PLL clock (default)
	while(!(CLK->CLKSTATUS & CLK_CLKSTATUS_PLL_STB_Msk));
	//PLL configuration ends
	
	//clock source selection
	CLK->CLKSEL0 &= (~(0x07ul << 0));
	CLK->CLKSEL0 |= (0x02 << 0); // Choose PLL as HCLK
	//clock frequency division = 1/(0+1)
	CLK->CLKDIV &= (~0x0Ful << 0);
	
	//CLK->CLKSEL0 &= ~(7ul << 0); //clock source selection ex 12Mhz for CPU	
	//CLK->CLKDIV &= (~0x0Ful << 0); //clock frequency division = 1/(0+1)
	
	SYS_LockReg(); // Lock protected registers

	// TIMER0 clk config
	CLK->CLKSEL1 &= ~(7ul << 8); // TIMER0 clk ex 12Mhz
	CLK->APBCLK |= (1ul << 2);	  // enable timer 0

	// TIMER1 clk config
	CLK->CLKSEL1 &= ~(7ul << 12); // TIMER1 clk ex 12Mhz
	CLK->APBCLK |= (1ul << 3);	  // enable timer 1

	// UART0 clk config
	CLK->CLKSEL1 &= ~(3ul << 24);
	CLK->CLKSEL1 |= (3ul << 24); // UART0 clock source is 22.1184 MHz
	CLK->CLKDIV &= ~(0xFul << 8); // clock divider is 1
	CLK->APBCLK |= (1ul << 16); // enable uart
	
	CLK->APBCLK |= (1ul << 15); // enable spi3
	
	// Enable the 4 LED
	GPIO_SetMode(PC, BIT12, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PC, BIT13, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PC, BIT14, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PC, BIT15, GPIO_MODE_OUTPUT);
	
	// Configure GPIO for Key Matrix
	OpenKeyPad();
	GPIO_ENABLE_DEBOUNCE(PA, BIT0);
	GPIO_ENABLE_DEBOUNCE(PA, BIT1);
	GPIO_ENABLE_DEBOUNCE(PA, BIT2);
	GPIO_ENABLE_DEBOUNCE(PA, BIT3);
	GPIO_ENABLE_DEBOUNCE(PA, BIT4);
	GPIO_ENABLE_DEBOUNCE(PA, BIT5);
	
	// Configure GPIO for 7segment
	OpenSevenSegment();

	// GPB15 config
	GPIO_SetMode(PB, BIT15, GPIO_MODE_INPUT);
	GPIO_EnableInt(PB, 15, GPIO_INT_FALLING);
	NVIC_EnableIRQ(EINT1_IRQn);
	NVIC_SetPriority(EINT1_IRQn, 0);

	//Turn on hardware debounce
	GPIO_ENABLE_DEBOUNCE(PB, BIT15);
	GPIO_SET_DEBOUNCE_TIME(GPIO_DBCLKSRC_LIRC, GPIO_DBCLKSEL_256);

	// Buzzer
	GPIO_SetMode(PB, BIT22, GPIO_MODE_OUTPUT);
	
	//----
	TIMER0_Config();
	TIMER1_Config();
	UART0_Config();
	SPI3_Config();
	start_LCD();
	clear_LCD();
}

void TIMER0_Config(void){
	TIMER0->TCSR &= ~(0xFFul << 0); // prescale 1
	TIMER0->TCSR |= (1ul << 16); // TDR to  be  updated  continuously  while  timer   counter   is  counting
	TIMER0->TCSR &= ~(1ul << 24); // disable counter mode
	TIMER0->TCSR |= (1ul << 26); // reset   Timer   0
	TIMER0->TCSR &= (0x3ul << 27);
	TIMER0->TCSR |= (1ul << 27); // periodic  mode
	TIMER0->TCSR |= (1ul << 29); // enable interrupt
	TIMER0->TCMPR = 60000-1; // T = 0.005s - 5 ms 
	TIMER0->TCSR |= (1ul << 30); // start counting
	//Enable TIMER0 interrupt
	NVIC_EnableIRQ(TMR0_IRQn);
	NVIC_SetPriority(TMR0_IRQn, 1);
}
void TIMER1_Config(void){
	TIMER1->TCSR &= ~(0xFFul << 0); // prescale 1
	TIMER1->TCSR |= (1ul << 16); // TDR to  be  updated  continuously  while  timer   counter   is  counting
	TIMER1->TCSR &= ~(1ul << 24); // disable counter mode
	TIMER1->TCSR |= (1ul << 26); // reset   Timer   0
	TIMER1->TCSR &= (0x3ul << 27);
	TIMER1->TCSR |= (1ul << 27); // periodic  mode
	TIMER1->TCSR |= (1ul << 29); // enable interrupt
	TIMER1->TCMPR = 3000000-1; // T = 0.25s - 250ms 
	TIMER1->TCSR |= (1ul << 30); // start counting
	//Enable TIMER1 interrupt
	NVIC_EnableIRQ(TMR1_IRQn);
	NVIC_SetPriority(TMR1_IRQn, 2);
}
void UART0_Config(void) {
	// UART0 Tx pin config
	GPIO_SetMode(PB, BIT0, GPIO_MODE_INPUT);
	GPIO_SetMode(PB, BIT1, GPIO_MODE_OUTPUT);
	SYS->GPB_MFP |= (SYS_GPB_MFP_PB0_UART0_RXD | SYS_GPB_MFP_PB1_UART0_TXD); // PORTB0 as UART0 Rx & PORTB1 as UART0 Tx	
	
	// UART0 operation config
	UART0->LCR |= (3ul << 0); // set word length 8-bit
	UART0->LCR &= ~(1ul << 2); // set 1-stop bit
	UART0->LCR &= ~(1ul << 3);  // no parity bit
	UART0->FCR |= (1ul << 1); // reset Rx pointer
	UART0->FCR |= (1ul << 2); // reset Tx pointer
	UART0->FCR &= ~(0xFul << 16); // set auto-trigger level 1 byte
	// set Baud rate mode 0 // pg 364
	//--> Mode 0, Baud rate = UART_CLK/[16*(A+2)] = 22.1184 MHz/[16*(10+2)]= 115200 bps
	UART0->BAUD &= ~(1ul << 28); // DIV_X_ONE = 0
	UART0->BAUD &= ~(1ul << 29); // DIV_X_ENF disable
	UART0->BAUD &= ~(0xFFFFul << 0);
	UART0->BAUD |= 10; // set BRD
	
	//enable UART02 interrupt
	UART_EnableInt(UART0, UART_IER_RDA_IEN_Msk);
	NVIC_EnableIRQ(UART02_IRQn);
	NVIC_SetPriority(UART02_IRQn, 0);
}

void SPI3_Config(void) {
	SYS->GPD_MFP |= SYS_GPD_MFP_PD8_SPI3_SS0 | SYS_GPD_MFP_PD9_SPI3_CLK | SYS_GPD_MFP_PD11_SPI3_MOSI0;

	SPI3->CNTRL &= ~(1ul << 23); //0: disable variable clock feature
	SPI3->CNTRL &= ~(1ul << 22); //0: disable two bits transfer mode
	SPI3->CNTRL &= ~(1ul << 18); //0: select Master mode
	SPI3->CNTRL &= ~(1ul << 17); //0: disable SPI interrupt    
	SPI3->CNTRL |= (1 << 11); //1: SPI clock idle high 
	SPI3->CNTRL &= ~(1ul << 10); //0: MSB is sent first   
	SPI3->CNTRL &= ~(3ul << 8); //00: one transmit/receive word will be executed in one data transfer

	SPI3->CNTRL &= ~(31ul << 3); //Transmit/Receive bit length
	SPI3->CNTRL |= 9 << 3;     //9: 9 bits transmitted/received per data transfer
	SPI3->CNTRL |= (1 << 2);  //1: Transmit at negative edge of SPI CLK       
	SPI3->DIVIDER = 24; // SPI clock divider. SPI clock = HCLK / ((DIVIDER+1)*2). HCLK = 50 MHz
}

void start_LCD(void){
    lcdWriteCommand(0xE2); // Set system reset
    lcdWriteCommand(0xA1); // Set Frame rate 100 fps  
    lcdWriteCommand(0xEB); // Set LCD bias ratio E8~EB for 6~9 (min~max)  
    lcdWriteCommand(0x81); // Set V BIAS potentiometer
    lcdWriteCommand(0xA0); // Set V BIAS potentiometer: A0 ()           
    lcdWriteCommand(0xC0);
    lcdWriteCommand(0xAF); // Set Display Enable
}
