#include <stdio.h>
#include "NUC100Series.h"
#include "game.h"
#include "Scankey.h"
#include "LCD.h"
#include "Seven_Segment.h"

#define MAX_BLINK_TIME 3*2
#define MAX_BUZZ_TIME 5*2

enum game_state {WELCOME, LOAD, GAME, END};
enum game_state state = WELCOME;

uint8_t game_board_X = 0;
uint8_t game_board_Y = 0;
uint8_t zeroXoneY = 0;
uint8_t curr_X_coord = 0;
uint8_t curr_Y_coord = 0;
uint8_t seven_seg_idx = 0;
uint8_t no_of_shots = 0;
uint8_t seven_seg_display[4] = {0,0,0,0};
uint8_t blink_time = 0;
uint8_t buzz_time = 0;

_Bool isUserInputInvalid = FALSE;
_Bool isWon = FALSE;
_Bool isUploaded = FALSE;
_Bool isPlaying = FALSE;
_Bool isBtn15Pressed = FALSE;
_Bool isHitTarget = FALSE;
_Bool isEndGame = FALSE;
_Bool isBuzzed = FALSE;



volatile char received_byte;
volatile _Bool TMR0_IRQ_flag = FALSE;
volatile _Bool TMR1_IRQ_flag = FALSE;
volatile _Bool UART02_IRQ_flag = FALSE;

// Board game declaration
uint8_t game_board[8][8] = {
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0}
};

uint8_t player_board[8][8] = {
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0}
};



void game_start(void){
	if(TMR0_IRQ_flag){
		CloseSevenSegment();
		ShowSevenSegment(seven_seg_idx, seven_seg_display[seven_seg_idx]);
		seven_seg_idx++;
		if(seven_seg_idx == 2) seven_seg_idx++;
		if(seven_seg_idx > 3) seven_seg_idx=0;
		TMR0_IRQ_flag = FALSE;
	}
	if(TMR1_IRQ_flag){
		if(isPlaying){
			handle_Keypad();
		}
		if(isHitTarget){
			blink_hit_target();
		}
		if(isEndGame){
			buzzer_endgame();
		}
		TMR1_IRQ_flag = FALSE;
	}

	switch (state){
		case WELCOME:
			handle_welcome();
			break;
		case LOAD:
			handle_load();
			break;
		case GAME:
			handle_game();
			break;
		case END:
			handle_end();
			break;
	}
}

//////////////Game State Handler///////////////////////////
void handle_welcome(void){
	clear_LCD();
	printS_5x7(25, 0, "BATTLESHIP GAME");
	printS_5x7(40, 8, "GROUP 14");
	printS_5x7(5,16, "Waiting for game map...");
	set_Shots_No_7seg(no_of_shots);
	ShowSevenSegment(0,0);
	ShowSevenSegment(1,10);
	ShowSevenSegment(3,0);
	state = LOAD;
}

void handle_load(void){
	if (isUploaded){
		PC14 = 0;
		printS_5x7(5,16, "Map loaded successfully");
		printS_5x7(5,24, "Press Btn15 to start");
		if (isBtn15Pressed){
			clear_LCD();
			reset_player_board();
			reset_seven_seg_display();
			display_player_board();
			//display_game_board(); // display game board for testing only
			no_of_shots = 0;
			isBuzzed = FALSE;
			isPlaying = TRUE;
			state = GAME;
			isBtn15Pressed = FALSE;
		}
	} else{
		PC14 = 1;
		// Loading game board
		if (UART02_IRQ_flag){
			if (received_byte != ' ' && received_byte != '\n' && received_byte != '\r' && received_byte != '\t'){
				if (received_byte == '1'){
					game_board[game_board_Y][game_board_X] = 1;
				} else{
					game_board[game_board_Y][game_board_X] = 0;
				}
				game_board_X++;
				if (game_board_X == 8){
					game_board_X = 0;
					game_board_Y++;
				}
				if (game_board_Y == 8){
					isUploaded = TRUE;
				}
			}
			UART0_Send(received_byte); // send back data
			UART02_IRQ_flag = FALSE;
		}
	}
}

void handle_game(void){
	if(zeroXoneY){
		printS_5x7(80,0,"Set Y");
	} else{
		printS_5x7(80,0,"Set X");
	}

	if (isBtn15Pressed){
		shoot();
		display_player_board();
		check_game_condition();
		isBtn15Pressed = FALSE;
	}
}

void handle_end(void){
	if (isWon){
		printS_5x7(0, 0, "You win");
	} else{
		printS_5x7(0, 0, "You lose");
	}

	if (isBtn15Pressed){
		reset_player_board();
		no_of_shots = 0;
		isBuzzed = FALSE;
		state = WELCOME;
		isBtn15Pressed = FALSE;
	}
}
//////////////////Ultilities function
void check_game_condition(void){
	if (no_of_shots > 16){
		isPlaying = TRUE;
		clear_LCD();
		isWon = FALSE;
		isEndGame = TRUE;
		state = END;
	} else{
		_Bool missTarget= FALSE;
		for (uint8_t i = 0; i < 8; i++){
			for (uint8_t j = 0; j < 8; j++){
				if (player_board[i][j] != game_board[i][j]){
					missTarget = TRUE;
					break;
				}
			}
		}
		if (!missTarget){
			isPlaying = FALSE;
			clear_LCD();
			isWon = TRUE;
			isEndGame = TRUE;
			state = END;
		}
	}
}

void shoot(void){
	no_of_shots++;
	set_Shots_No_7seg(no_of_shots);
	
	if(curr_X_coord == 0 || curr_Y_coord == 0){
		return;
	}
	// if the shoot hit
	if (game_board[curr_Y_coord - 1][curr_X_coord - 1] == 1){ 
		player_board[curr_Y_coord - 1][curr_X_coord - 1] = 1;
		isHitTarget = TRUE;
	}
	
	// reset curr coord
	curr_X_coord = 0;
	curr_Y_coord = 0;
	if (zeroXoneY){
		seven_seg_display[3] = curr_Y_coord;
		zeroXoneY = 0;
	}	else{
		seven_seg_display[3] = curr_X_coord;
	}
}

void blink_hit_target(void){
	PC->DOUT ^= (1 << 12);
	blink_time++;
	if(blink_time > MAX_BLINK_TIME){
		PC12 = 1;
		isHitTarget = FALSE;
		blink_time = 0;
	}
}

void reset_player_board(){
	for (uint8_t i = 0; i < 8; i++){
		for (uint8_t j = 0; j < 8; j++){
			player_board[i][j] = 0;
		}
	}
}

void reset_seven_seg_display(void){
	for (uint8_t i = 0; i < sizeof(seven_seg_display); i++){
		seven_seg_display[i] = 0;
	}
}

void display_player_board(){
	for (uint8_t i = 0; i < 8; i++){
		for (uint8_t j = 0; j < 8; j++){
			if (player_board[i][j] == 0){
				printC_5x7(j * 8, i * 8, '_');
			}	else{
				printC_5x7(j * 8, i * 8, 'X');
			}
		}
	}
}

void display_game_board(){
	for (uint8_t i = 0; i < 8; i++){
		for (uint8_t j = 0; j < 8; j++){
			if (game_board[i][j] == 0){
				printC_5x7(j * 8, i * 8, '_');
			}	else{
				printC_5x7(j * 8, i * 8, 'X');
				
			}
		}
	}
}

void buzzer_endgame(){
	PB->DOUT ^= (1 << 11);
	buzz_time++;
	if(buzz_time > MAX_BUZZ_TIME){
		PB11 = 1;
		//isBuzzed = TRUE; // Buzzer buzz 5 time
		isEndGame = FALSE;
		buzz_time = 0;
	}
}

void handle_Keypad(void){
	isUserInputInvalid = FALSE;
	uint8_t tmp = ScanKey();
	if(tmp != 0){
		if(tmp != 9){
			if (zeroXoneY == 0) {
				curr_X_coord = tmp;
			} else {
				curr_Y_coord = tmp;
			}
		} else {
			if (zeroXoneY == 0) {
					zeroXoneY = 1;
			} else if (zeroXoneY == 1){
					zeroXoneY = 0;
			}
		}
	}
		
	if (zeroXoneY == 0) {
		seven_seg_display[3] = curr_X_coord;
	} else {
		seven_seg_display[3] = curr_Y_coord;
	}
}

void set_Shots_No_7seg(uint8_t shot) {
	uint8_t dozen = shot / 10;
	uint8_t units = shot % 10;
	seven_seg_display[0] = units;
	seven_seg_display[1] = dozen;
}

void UART0_Send(uint8_t data){
	while(UART0->FSR & (0x01 << 23)); //wait until TX FIFO is not full
	UART0->DATA = data;
	if (data == '\n') { // \n is new line
		while(UART0->FSR & (0x01 << 23));
		UART0->DATA = '\r'; // '\r' - Carriage
		return;
	}
}



//////////////////////Interrupt service routine//////////////////////////
void EINT1_IRQHandler(void){
	isBtn15Pressed = TRUE;
	PB->ISRC |= (1 << 15);
}

void TMR0_IRQHandler(void){
	TMR0_IRQ_flag = TRUE;
	/*
	CloseSevenSegment();
	ShowSevenSegment(seven_seg_idx, seven_seg_display[seven_seg_idx]);
	seven_seg_idx++;
	if(seven_seg_idx == 2) seven_seg_idx++;
	if(seven_seg_idx > 3) seven_seg_idx=0;
	*/
	TIMER0->TISR |= (1 << 0);
}

void TMR1_IRQHandler(void){
	TMR1_IRQ_flag = TRUE;
	TIMER1->TISR |= (1 << 0);
}

void UART02_IRQHandler(void){
	UART02_IRQ_flag = TRUE;
	received_byte = UART0->RBR;
	//because ISR is read only no need to reset manually
}
