//------------------------------------------- main.c CODE STARTS ---------------------------------------------------------------------------
#include <stdio.h>
#include "NUC100Series.h"
#include "Start_Up.h"
#include "game.h"

int main(void){
	Start_Up();
	while (1){
		game_start();
	}
}
