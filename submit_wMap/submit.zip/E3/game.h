#ifndef GAME_INCLUDED
#define GAME_INCLUDED

    void game_start(void);
    void handle_welcome(void);
    void handle_load(void);
    void handle_game(void);
    void handle_end(void);
    void check_game_condition(void);
    void shoot(void);
    void blink_hit_target(void);
    void reset_player_board(void);
    void reset_seven_seg_display(void);
    void display_player_board(void);
    void display_game_board(void);
    void buzzer_endgame(void);
    void handle_Keypad(void);
    void set_Shots_No_7seg(uint8_t shot);
    void UART0_Send(uint8_t data);
    void EINT1_IRQHandler(void);
    void TMR0_IRQHandler(void);
    void TMR1_IRQHandler(void);
    void UART02_IRQHandler(void);
		
#endif