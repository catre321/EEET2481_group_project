#ifndef STARTUP_INCLUDED
#define STARTUP_INCLUDED

	void TIMER0_Config(void);
	void TIMER1_Config(void);
	void UART0_Config(void);
	void SPI3_Config(void);
	void start_LCD(void);
	void Start_Up(void);

#endif