#include <stdio.h>
#include "NUC100Series.h"
#include "LCD.h"

void System_Config(void);
void TIMER0_Config(void);
void SPI2_Config(void);
void SPI3_Config(void);
void SPI2_SendTx(unsigned char temp);
void LCD_start(void);
void ADC7_Config(void);
void TMR0_IRQHandler(void);
void ADC_IRQHandler(void);

volatile _Bool TMR0_IRQ_flag = FALSE;
volatile _Bool ADC_IRQ_flag = FALSE;
_Bool isAbove2V = FALSE;
const char send[3] = "G14";

int main(void)
{
	uint32_t adc7_val;
	char adc7_val_s[4] = "0000";

	System_Config();
	TIMER0_Config();
	SPI2_Config();
	SPI3_Config();
	ADC7_Config();
	
	GPIO_SetMode(PA, 12, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PA, 13, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PC, 15, GPIO_MODE_OUTPUT);
	
	LCD_start();
	clear_LCD();
	
	//--------------------------------
	// LCD static content
	//--------------------------------
	
	printS_5x7(2, 0, "EEET2481 Ex2 SPI and ADC ");
	printS_5x7(2, 8, "ADC7 conversion test");
	printS_5x7(2, 16, "Reference voltage: 3.3 V");
	printS_5x7(2, 24, "A/D resolution: 0.8058 mV");
	printS_5x7(2, 32, "A/D value:");
	
	ADC->ADCR |= (1 << 11); // start ADC channel 7 conversion
	
	PC15 = 0; //LED8 on

	while (1) {
		while (!(ADC->ADSR & (1 << 0))); // wait until conversion is completed (ADF=1)
		ADC->ADSR |= (1 << 0); // write 1 to clear ADF
		adc7_val = ADC->ADDR[7] & 0x0000FFFF;
		
		sprintf(adc7_val_s, "%d", adc7_val);
		
		if(TMR0_IRQ_flag){
		printS_5x7(4 + 5 * 10, 32, "    ");
		printS_5x7(4 + 5 * 10, 32, adc7_val_s);
			if(ADC_IRQ_flag){
				PA12 = 1; //blue LED off
				PA13 = 0; //green LED on
				printS_5x7(58, 48, send); //display msg
				for(unsigned int i=0;i<sizeof(send);i++){
					SPI2_SendTx(send[i]);
				}
			ADC_IRQ_flag = FALSE; //reset flag
		} else{
			printS_5x7(58, 48, "   ");
			PA12 = 0; //blue LED on
			PA13 = 1; //green LED off
		}
		TMR0_IRQ_flag = FALSE; // reset flag
	}
	}
}

//------------------------------------------------------------------------------------------------------------------------------------
// Functions definition
//------------------------------------------------------------------------------------------------------------------------------------
void System_Config(void) {
	SYS_UnlockReg(); // Unlock protected registers
	
	CLK->PWRCON |= CLK_PWRCON_XTL12M_EN_Msk; // Enable HXT clock
  while(!(CLK->CLKSTATUS & CLK_CLKSTATUS_HXT_STB_Msk));
	
	//PLL configuration starts
	CLK->PLLCON &= ~(1ul<<19); //0: PLL input is HXT 12MHz (default). 1: PLL input is HIRC 22MHz
	CLK->PLLCON &= ~(1ul<<16); //0: PLL in normal mode. 1: PLL in power-down mode (default)
	CLK->PLLCON &= (~(0x01FFul << 0));
	CLK->PLLCON |= 48; //frequency: 50 MHz
	CLK->PLLCON &= ~(1ul<<18); //0: enable PLL clock out. 1: disable PLL clock (default)
	while(!(CLK->CLKSTATUS & CLK_CLKSTATUS_PLL_STB_Msk));
	//PLL configuration ends
	
	//clock source selection
	CLK->CLKSEL0 &= (~(0x07ul << 0));
	CLK->CLKSEL0 |= (0x02 << 0); // Choose PLL as HCLK
	//clock frequency division = 1/(0+1)
	CLK->CLKDIV &= (~0x0Ful << 0);
	
	SYS_LockReg();  // Lock protected registers  
	
	// TIMER0 clk config
	CLK->CLKSEL1 &= ~(7ul << 8); // TIMER0 clk ex 12Mhz
	CLK->APBCLK |= (1 << 2);	  // enable timer 0
	
	// SPI2 clock enable
	CLK->APBCLK |= 1 << 14;
	// SPI3 clock enable
	CLK->APBCLK |= 1 << 15;
	
	//ADC Clock selection and configuration
	CLK->CLKSEL1 &= ~(0x03ul << 2); // ADC clock source is 12 MHz
	CLK->CLKDIV &= ~(0x0FFul << 16);
	CLK->CLKDIV |= (0x0B << 16); // ADC clock divider is (11+1) --> ADC clock is 12/12 = 1 MHz
	CLK->APBCLK |= (0x01 << 28); // enable ADC clock 	
}

void TIMER0_Config(void){
	TIMER0->TCSR &= ~(0xFFul << 0); // prescale 1
	TIMER0->TCSR |= (1ul << 16)  ; // TDR to  be  updated  continuously  while  timer   counter   is  counting
	TIMER0->TCSR &= ~(1ul << 24); // disable counter mode
	TIMER0->TCSR |= (1ul << 26); // reset   Timer   0
	TIMER0->TCSR &= (3ul << 27);
	TIMER0->TCSR |= (1 << 27); // periodic  mode
	TIMER0->TCSR |= (1 << 29); // enable interrupt
	TIMER0->TCMPR = 240000-1; // T = 0.02s - 20 ms 
	TIMER0->TCSR |= (1 << 30); // start counting
	//Enable TIMER0 interrupt
	NVIC_EnableIRQ(TMR0_IRQn);
	NVIC_SetPriority(TMR0_IRQn, 1);
}

void SPI2_Config(void) {
	SYS->GPD_MFP |= 1 << 0; // 1: PD0 is configured for alternative function SS20
	SYS->GPD_MFP |= 1 << 1; // 1: PD1 is configured for alternative function SPICLK
	SYS->GPD_MFP |= 1 << 3; // 1: PD2 is configured for alternative function MOSI0

	SPI2->CNTRL &= ~(1ul << 23); // 0: disable variable clock feature
	SPI2->CNTRL &= ~(1ul << 22); // 0: disable two bits transfer mode
	SPI2->CNTRL &= ~(1ul << 18); // 0: select Master mode
	SPI2->CNTRL &= ~(1ul << 17); // 0: disable SPI interrupt
	SPI2->CNTRL |= (1 << 11);		 // 1: SPI clock idle high
	SPI2->CNTRL |= (1 << 10);	 // 1: LSB is sent first
	SPI2->CNTRL &= ~(3ul << 8); // 00: one transmit/receive word will be executed in one data transfer
	
	SPI2->CNTRL &= ~(31ul << 3);
	SPI2->CNTRL |= 9 << 3;	  // 9 bits/word
	SPI2->CNTRL &= ~(1ul << 2); // 0: Transmit at positive edge of SPI CLK
	SPI2->DIVIDER = 24; // SPI clock divider. SPI clock = HCLK / ((DIVIDER+1)*2). HCLK = 50MHz
}

void SPI3_Config(void) {	
	SYS->GPD_MFP |= 1 << 11; //1: PD11 is configured for SPI3
	SYS->GPD_MFP |= 1 << 9; //1: PD9 is configured for SPI3
	SYS->GPD_MFP |= 1 << 8; //1: PD8 is configured for SPI3

	SPI3->CNTRL &= ~(1ul << 23); //0: disable variable clock feature
	SPI3->CNTRL &= ~(1ul << 22); //0: disable two bits transfer mode
	SPI3->CNTRL &= ~(1ul << 18); //0: select Master mode
	SPI3->CNTRL &= ~(1ul << 17); //0: disable SPI interrupt    
	SPI3->CNTRL |= (1 << 11); //1: SPI clock idle high 
	SPI3->CNTRL &= ~(1ul << 10); //0: MSB is sent first   
	SPI3->CNTRL &= ~(3ul << 8); //00: one transmit/receive word will be executed in one data transfer

	SPI3->CNTRL &= ~(31ul << 3); //Transmit/Receive bit length
	SPI3->CNTRL |= 9 << 3;     //9: 9 bits transmitted/received per data transfer
	SPI3->CNTRL |= (1 << 2);  //1: Transmit at negative edge of SPI CLK       
	SPI3->DIVIDER = 24; // SPI clock divider. SPI clock = HCLK / ((DIVIDER+1)*2). HCLK = 50 MHz
}

void SPI2_SendTx(unsigned char temp){
  SPI_SET_SS0_LOW(SPI2);
  SPI_WRITE_TX0(SPI2, temp); // Write Data
  SPI_TRIGGER(SPI2);         // Trigger SPI data transfer           
  while(SPI_IS_BUSY(SPI2));  // Check SPI2 busy status
  SPI_SET_SS0_HIGH(SPI2);	
}
void LCD_start(void){
	lcdWriteCommand(0xE2); // Set system reset
	lcdWriteCommand(0xA1); // Set Frame rate 100 fps  
	lcdWriteCommand(0xEB); // Set LCD bias ratio E8~EB for 6~9 (min~max)  
	lcdWriteCommand(0x81); // Set V BIAS potentiometer
	lcdWriteCommand(0xA0); // Set V BIAS potentiometer: A0 ()        	
	lcdWriteCommand(0xC0);
	lcdWriteCommand(0xAF); // Set Display Enable
}
void ADC7_Config(void) {
	GPIO_SetMode(PA, 7, GPIO_MODE_INPUT); // PA.7 is input pin
	PA->OFFD |= (0x01ul << 7); // PA.7 digital input path is disabled
	SYS->GPA_MFP |= (0x01ul << 7); // GPA_MFP[7] = 1 for ADC7
	SYS->ALT_MFP &= ~(0x01ul << 11); //ALT_MFP[11] = 0 for ADC7

	//ADC operation configuration
	ADC->ADCR |= (0x03 << 2); // continuous scan mode
	ADC->ADCR &= ~(0x01ul << 1); // ADC interrupt is disabled
	ADC->ADCR |= (0x01 << 0); // ADC is enabled
	ADC->ADCHER &= ~(0x03ul << 8); // ADC7 input source is external pin
	ADC->ADCHER |= (0x01 << 7); // ADC channel 7 is enabled.
	
	//ADC interrupt
	ADC->ADCR |= (1 << 0);
	NVIC->ISER[0] |= (1 << 29); // Enable ADC interrupt
	NVIC->IP[7] &= ~(3ul << 14); // Set priority to 0
	
	//Compare config
	ADC->ADCMPR[0] |= (1ul << 0); //cmpr enable
	ADC->ADCMPR[0] |= (1ul << 1); //cmpr interrupt enable
	ADC->ADCMPR[0] |= (1ul << 2); //set interrupt if data >= cmpr value
	ADC->ADCMPR[0] |= (7 << 3); //select channel 7 result to be cmpr
	ADC->ADCMPR[0] |= (2000 << 16); // comparision data

}

void TMR0_IRQHandler(void){
	TMR0_IRQ_flag = TRUE;
	TIMER0->TISR |= (1ul << 0);
}

void ADC_IRQHandler(void){
	ADC_IRQ_flag = TRUE;
	ADC->ADSR |= (1ul << 1); //reset cmpr flag
}
